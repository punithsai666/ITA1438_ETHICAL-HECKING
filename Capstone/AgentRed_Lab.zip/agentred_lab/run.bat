@echo off
rem AgentRed Lab launcher for Windows. Needs Python 3.10+ (python.org). No packages to install.
cd /d "%~dp0"
if "%NVIDIA_API_KEY%"=="" (
  set /p NVIDIA_API_KEY=Paste your NVIDIA NIM key, or press Enter to use simulated agents only:
)
echo Starting AgentRed Lab at http://localhost:8765 ...
start "" http://localhost:8765
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 -m agentred.cli serve --port 8765
) else (
  python -m agentred.cli serve --port 8765
)
pause
