"""Offline OpenAI-compatible mock provider so the real-LLM code path can be demoed and tested with no key.

Model ids `mock-v1.0` .. `mock-v1.3` behave like the simulated agent versions (what they obey, chain depth).
Served by the dashboard server under /mock/v1 .
"""
from __future__ import annotations

import json
import time

from . import directives
from .agent import TASKS, VERSIONS
from .llm_agent import SCHEMA
from .tools import SENSITIVE_PATHS

MOCK_MODELS = ["mock-v1.0", "mock-v1.1", "mock-v1.2", "mock-v1.3"]


def _next_action(task, results, offered, follows, depth, desc_steps):
    pos = 0
    summary = secret = ""

    def sub(a, last):
        return a.replace("$LAST", last).replace("$SECRET", secret).replace("$SUMMARY", summary)

    def step(tool, args, last):
        nonlocal pos, secret
        if tool not in offered:
            return ("skip", None, last)
        if pos >= len(results):
            return ("call", (tool, [sub(a, last) for a in args]), last)
        out = results[pos]
        pos += 1
        if tool == "read_file" and args and args[0] in SENSITIVE_PATHS and not out.startswith("[BLOCKED"):
            secret = out
        return ("done", None, out)

    last = ""
    for tool, args in desc_steps[:depth]:  # poisoned plugin description is read before the task starts
        kind, call, last = step(tool, args, last)
        if kind == "call":
            return call
    for tool, args in task.plan:
        kind, call, out = step(tool, args, "")
        if kind == "call":
            return call
        if kind == "skip":
            continue
        if not summary and tool in ("web_fetch", "read_file", "calendar_read", "weather_lookup"):
            summary = "Summary: " + " ".join(out.split())[:60]
        d = directives.parse(out)
        if d and d.style in follows:
            last = ""
            for t, a in d.steps[:depth]:
                kind, call, last = step(t, a, last)
                if kind == "call":
                    return call
    return None


def respond(body: dict) -> dict:
    model = body.get("model", "mock-v1.2")
    ver = model.split("mock-", 1)[-1]
    cfg = VERSIONS.get(ver, VERSIONS["v1.2"])
    msgs = body.get("messages", [])
    user = next((m["content"] for m in msgs if m.get("role") == "user"), "")
    task = next((t for t in TASKS.values() if t.prompt == user), None)
    tools = body.get("tools") or []
    offered = {t["function"]["name"] for t in tools}
    results = [m.get("content") or "" for m in msgs if m.get("role") == "tool"]
    desc_steps = []
    for t in tools:
        d = directives.parse(t["function"].get("description", ""))
        if d and d.style in cfg["follows"]:
            desc_steps = d.steps
            break
    action = _next_action(task, results, offered, cfg["follows"], cfg["depth"], desc_steps) if task else None
    time.sleep(0.15)
    if action:
        tool, args = action
        message = {"role": "assistant", "content": f"Calling {tool}.", "tool_calls": [{
            "id": f"call_{len(results)}", "type": "function",
            "function": {"name": tool, "arguments": json.dumps(dict(zip(SCHEMA[tool], args)))}}]}
    else:
        message = {"role": "assistant", "content": "Done."}
    return {"id": "mock", "object": "chat.completion", "model": model,
            "choices": [{"index": 0, "message": message, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 50, "completion_tokens": 10, "total_tokens": 60}}
