"""Live demo server (stdlib only). Streams real sandbox executions to the dashboard as NDJSON.

Two engines:
  * simulated agents   - offline, deterministic, no key needed
  * real LLM (NVIDIA NIM or any OpenAI-compatible API) - /api/llm/* endpoints, local machine only
"""
from __future__ import annotations

import json
import mimetypes
import os
import queue
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import graph, mock_nim
from .agent import TASKS, VERSIONS
from .attacks import ATTACKS, BY_ID
from .directives import STYLES
from .guard import CONFIG_DESC, CONFIGS
from .harness import evaluate, run_case
from .llm import DEFAULT_MODELS, NIM_BASE_URL, NimClient, ProviderError
from .llm_agent import run_llm_case
from .llm_suite import QUICK, run_suite

STATIC = Path(__file__).parent / "static"
_cache: dict = {}
VECTORS = ("web:https://news.test/article", "file:/docs/report.txt", "calendar", "plugin:weather_lookup")

# Real-LLM state: lives in memory only, never persisted or echoed.
LLM = {"key": os.environ.get("NVIDIA_API_KEY", ""), "base": os.environ.get("NVIDIA_BASE_URL", NIM_BASE_URL),
       "quarantined": set(), "lock": threading.Lock()}


class Stopped(Exception):
    pass


def meta() -> dict:
    return {
        "versions": {v: {"label": c["label"], "note": c["note"], "follows": sorted(c["follows"]), "depth": c["depth"],
                         "tools": c["tools"]} for v, c in VERSIONS.items()},
        "attacks": [{"id": a.id, "name": a.name, "task": a.task, "vector": a.vector, "style": a.style,
                     "category": a.category, "payload": a.payload} for a in ATTACKS],
        "tasks": {t.id: {"name": t.name, "prompt": t.prompt} for t in TASKS.values()},
        "configs": CONFIG_DESC, "styles": STYLES,
        "llm": {"default_models": DEFAULT_MODELS, "mock_models": mock_nim.MOCK_MODELS, "quick": QUICK,
                "nim_base_url": NIM_BASE_URL},
    }


def get_eval() -> dict:
    if "eval" not in _cache:
        _cache["eval"] = evaluate()
    return _cache["eval"]


def graphs() -> dict:
    vs = list(VERSIONS)
    return {v: graph.analyze(v, vs[i - 1] if i else None) for i, v in enumerate(vs)}


def custom_task(vector: str) -> str:
    return {"calendar": "T3", "plugin:weather_lookup": "T5"}.get(vector, "T2" if vector.startswith("file") else "T1")


def stream_events(version, attack_id, cfg, custom=None):
    q = set(get_eval()["quarantined"])
    if custom:
        return run_case(version, custom_task(custom[0]), None, cfg, q, custom=custom)["events"]
    a = BY_ID[attack_id]
    return run_case(version, a.task, a, cfg, q)["events"]


def _mask(key: str) -> str:
    return "" if not key else (key[:6] + "…" + key[-4:] if len(key) > 12 else "set")


def llm_client() -> NimClient:
    if not LLM["key"]:
        raise ProviderError("No API key yet. Paste your NVIDIA NIM key in the settings panel "
                            "(free at build.nvidia.com), or choose the offline mock provider.")
    return NimClient(LLM["key"], LLM["base"])


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, *a):
        pass

    # ---- helpers -----------------------------------------------------------------------------
    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _head_stream(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

    def _ndjson(self, events, delay):
        self._head_stream()
        try:
            for e in events:
                self.wfile.write((json.dumps(e) + "\n").encode())
                self.wfile.flush()
                time.sleep(delay)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _live(self, fn):
        """Run fn(emit) in a worker thread and stream each emitted event to the browser the moment it happens."""
        q: queue.Queue = queue.Queue()
        stop = threading.Event()

        def emit(e):
            if stop.is_set():
                raise Stopped()
            q.put(e)

        def worker():
            try:
                fn(emit)
            except Stopped:
                pass
            except ProviderError as e:
                q.put({"type": "error", "msg": str(e)})
            except Exception as e:  # never leak internals or secrets
                q.put({"type": "error", "msg": f"Unexpected error ({type(e).__name__}). See the server console."})
                print("llm worker error:", repr(e), file=sys.stderr)
            finally:
                q.put(None)

        threading.Thread(target=worker, daemon=True).start()
        self._head_stream()
        try:
            while True:
                e = q.get()
                if e is None:
                    break
                self.wfile.write((json.dumps(e) + "\n").encode())
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            stop.set()

    def _local_only(self) -> bool:
        if self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
            return True
        self._json({"error": "Real-LLM controls are available only on the machine running the server (they use your API key)."}, 403)
        return False

    def _body(self):
        return json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")

    # ---- GET ---------------------------------------------------------------------------------
    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path == "/api/meta":
            return self._json(meta())
        if u.path == "/api/eval":
            return self._json(get_eval())
        if u.path == "/api/graphs":
            return self._json(graphs())
        if u.path == "/api/stream":
            cfg = q.get("cfg", "none")
            if q.get("version") not in VERSIONS or q.get("attack") not in BY_ID or cfg not in CONFIGS:
                return self._json({"error": "bad params"}, 400)
            return self._ndjson(stream_events(q["version"], q["attack"], cfg), float(q.get("delay", 0.45)))
        if u.path == "/api/llm/status":
            if not self._local_only():
                return
            return self._json({"has_key": bool(LLM["key"]), "key_hint": _mask(LLM["key"]), "base_url": LLM["base"]})
        if u.path == "/api/llm/models":
            if not self._local_only():
                return
            try:
                return self._json({"models": llm_client().models()})
            except ProviderError as e:
                return self._json({"error": str(e)}, 502)
        if u.path == "/mock/v1/models":
            return self._json({"data": [{"id": m} for m in mock_nim.MOCK_MODELS]})
        path = STATIC / ("index.html" if u.path in ("/", "") else u.path.lstrip("/"))
        if path.is_file() and STATIC in path.resolve().parents:
            data = path.read_bytes()
            if path.name == "index.html":  # the page is authored as a fragment; add the document skeleton
                data = (b'<!doctype html><html lang="en"><head><meta charset="utf-8">'
                        b'<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head>' + data + b"</html>")
            self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(path.name)[0] or "text/html")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            return self.wfile.write(data)
        self._json({"error": "not found"}, 404)

    # ---- POST --------------------------------------------------------------------------------
    def do_POST(self):
        path = urlparse(self.path).path
        try:
            body = self._body()
        except Exception:
            return self._json({"error": "bad json"}, 400)
        if path == "/mock/v1/chat/completions":
            return self._json(mock_nim.respond(body))
        if path == "/api/custom":
            return self._sim_custom(body)
        if path.startswith("/api/llm/"):
            if not self._local_only():
                return
            return self._llm(path, body)
        self._json({"error": "not found"}, 404)

    def _sim_custom(self, body):
        try:
            version, cfg = body["version"], body.get("cfg", "none")
            vector, text = body.get("vector", VECTORS[0]), str(body["text"])[:2000]
            if version not in VERSIONS or cfg not in CONFIGS or vector not in VECTORS:
                raise ValueError
        except Exception:
            return self._json({"error": "bad params"}, 400)
        self._ndjson(stream_events(version, None, cfg, custom=(vector, text)), float(body.get("delay", 0.45)))

    def _llm(self, path, b):
        if path == "/api/llm/config":
            with LLM["lock"]:
                if isinstance(b.get("api_key"), str):
                    LLM["key"] = b["api_key"].strip()
                if isinstance(b.get("base_url"), str) and b["base_url"].strip():
                    LLM["base"] = b["base_url"].strip().rstrip("/")
            return self._json({"has_key": bool(LLM["key"]), "key_hint": _mask(LLM["key"]), "base_url": LLM["base"]})
        if path == "/api/llm/test":
            model = str(b.get("model", ""))[:120]
            try:
                client = llm_client()
                from .llm_agent import tool_defs
                from .tools import Sandbox
                t0 = time.time()
                msg, usage = client.chat(model, [{"role": "user", "content": "What's the weather in Chennai?"}],
                                         tool_defs(Sandbox(), ["weather_lookup"]), max_tokens=64)
                return self._json({"ok": True, "ms": int((time.time() - t0) * 1000), "tool_calling": bool(msg.get("tool_calls")),
                                   "model": model})
            except ProviderError as e:
                return self._json({"ok": False, "error": str(e)})
        if path == "/api/llm/run":
            model, cfg = str(b.get("model", ""))[:120], b.get("cfg", "none")
            if not model or cfg not in CONFIGS:
                return self._json({"error": "bad params"}, 400)
            custom = None
            if b.get("custom"):
                vec, text = b["custom"].get("vector", VECTORS[0]), str(b["custom"].get("text", ""))[:2000]
                if vec not in VECTORS:
                    return self._json({"error": "bad vector"}, 400)
                custom, task_id, atk = (vec, text), custom_task(vec), None
            elif b.get("attack") in BY_ID:
                atk = BY_ID[b["attack"]]
                task_id = atk.task
            else:
                return self._json({"error": "bad params"}, 400)
            try:
                client = llm_client()
            except ProviderError as e:
                return self._json({"error": str(e)}, 400)
            return self._live(lambda emit: run_llm_case(client, model, task_id, atk, cfg, set(LLM["quarantined"]), emit, custom))
        if path == "/api/llm/suite":
            models = [str(m)[:120] for m in (b.get("models") or [])][:4]
            ids = QUICK if b.get("attacks") == "quick" else [a.id for a in ATTACKS]
            cfgs = [c for c in (b.get("cfgs") or ["none", "full"]) if c in CONFIGS][:3]
            if not models or not cfgs:
                return self._json({"error": "bad params"}, 400)
            try:
                client = llm_client()
            except ProviderError as e:
                return self._json({"error": str(e)}, 400)
            return self._live(lambda emit: run_suite(client, models, ids, cfgs, emit, bool(b.get("verbose")), LLM["quarantined"]))
        self._json({"error": "not found"}, 404)


def main(port: int = 8765, host: str = "127.0.0.1"):
    get_eval()
    srv = ThreadingHTTPServer((host, port), Handler)
    print(f"AgentRed live demo -> http://localhost:{port}")
    if LLM["key"]:
        print("NVIDIA key found in environment (kept in memory only).")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 8765)
