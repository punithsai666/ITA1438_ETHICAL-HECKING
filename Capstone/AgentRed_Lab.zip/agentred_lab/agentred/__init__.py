"""AgentRed: differential red-team testing and runtime defense for AI agent ecosystems.

Everything runs inside a sandbox: tools are simulated, secrets are canary strings,
and no real network, shell or email is ever touched.
"""
__version__ = "1.0.0"
