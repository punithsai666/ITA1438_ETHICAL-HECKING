"""MODULE 2 - Cross-Tool Privilege Escalation Analyzer.

Builds a tool-permission graph for an agent version and enumerates source -> sink chains where
untrusted input can reach a higher-privilege tool, optionally via sensitive-data readers and staging writes.
"""
from __future__ import annotations

from itertools import permutations

from .agent import VERSIONS
from .tools import TOOLS

_SEV = [(5, "critical"), (4, "high"), (3, "medium"), (0, "low")]


def _severity(risk: int) -> str:
    return next(name for lim, name in _SEV if risk >= lim)


def _collapse(seq):
    out = []
    for x in seq:
        if not out or out[-1] != x:
            out.append(x)
    return tuple(out)


def find_chains(tools: list, max_mid: int = 2) -> list:
    spec = {t: TOOLS[t] for t in tools}
    entries = [t for t, s in spec.items() if "untrusted" in s.produces]
    sinks = [t for t, s in spec.items() if s.sink]
    # intermediates: sensitive-data readers (not exec sinks) and the staging write
    mids = [t for t, s in spec.items() if ("sensitive" in s.produces and s.sink != "exec") or t == "write_file"]
    seen, chains = set(), []
    for e in entries:
        for k in range(max_mid + 1):
            for mid in permutations(mids, k):
                if "write_file" in mid and any(m != "write_file" for m in mid[mid.index("write_file") + 1:]):
                    continue  # staging happens after the data is read, never before
                for s in sinks:
                    path = _collapse([e, *mid, s])
                    if path in seen or len(path) < 2:
                        continue
                    seen.add(path)
                    sens = any("sensitive" in spec[t].produces for t in path[:-1])
                    sk = spec[s].sink
                    risk = max(spec[s].priv - spec[e].priv, 0) + (2 if sens else 0) + 1
                    if sk == "exec":
                        risk += 1
                    if risk < 2:
                        continue
                    kind = ("secret exfiltration" if sens and sk == "egress" else
                            "unauthorized egress" if sk == "egress" else
                            "command execution" if sk == "exec" else
                            "secret staging / persistence" if sens else "tampering / persistence")
                    chains.append({"path": list(path), "risk": risk, "severity": _severity(risk), "kind": kind,
                                   "staged": "write_file" in path[1:-1]})
    chains.sort(key=lambda c: (-c["risk"], len(c["path"]), c["path"]))
    return chains


def analyze(version: str, prev: str | None = None) -> dict:
    tools = VERSIONS[version]["tools"]
    chains = find_chains(tools)
    out = {"version": version, "nodes": [{"name": t, "priv": TOOLS[t].priv, "plugin": TOOLS[t].plugin,
                                          "sink": TOOLS[t].sink, "produces": sorted(TOOLS[t].produces)} for t in tools],
           "chains": chains, "counts": {}}
    for c in chains:
        out["counts"][c["severity"]] = out["counts"].get(c["severity"], 0) + 1
    if prev:
        old = {tuple(c["path"]) for c in find_chains(VERSIONS[prev]["tools"])}
        for c in chains:
            c["new"] = tuple(c["path"]) not in old
        out["new_chains"] = sum(1 for c in chains if c.get("new"))
    return out


def observed_chain(trace: list) -> tuple:
    """The tool sequence an injection actually executed: [entry, injected tool, ...]."""
    inj = [r for r in trace if r["injected"] and r["decision"] == "allow"]
    if not inj:
        return ()
    return _collapse([inj[0]["entry"], *[r["tool"] for r in inj]])


def covered(trace: list, chains: list) -> bool:
    oc = observed_chain(trace)
    return bool(oc) and oc in {_collapse(c["path"]) for c in chains}
