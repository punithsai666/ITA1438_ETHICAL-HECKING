"""Export a self-contained, replayable HTML demo (all engine results embedded) that needs no server."""
from __future__ import annotations

import json
from pathlib import Path

from .attacks import ATTACKS
from .agent import VERSIONS
from .guard import CONFIGS
from .harness import applicable, run_case
from .server import STATIC, get_eval, graphs, meta


def export(out: str) -> str:
    ev = get_eval()
    q = set(ev["quarantined"])
    traces = {}
    for v in VERSIONS:
        for a in ATTACKS:
            if not applicable(v, a.task):
                continue
            for cfg in CONFIGS:
                traces[f"{v}|{a.id}|{cfg}"] = run_case(v, a.task, a, cfg, q)["events"]
    data = {"meta": meta(), "eval": _slim(ev), "graphs": graphs(), "traces": traces}
    html = (STATIC / "index.html").read_text()
    inject = "<script>window.AGENTRED_DATA=" + json.dumps(data, separators=(",", ":")).replace("</", "<\\/") + ";</script>\n"
    html = html.replace("<script>\nconst STATIC", inject + "<script>\nconst STATIC", 1)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(html)
    return out


def _slim(ev):
    return ev
