"""Command line: `python -m agentred.cli eval|demo|serve|export`."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .attacks import ATTACKS, BY_ID
from .guard import CONFIG_DESC
from .harness import evaluate, run_case

ROOT = Path(__file__).resolve().parent.parent
R, G, Y, D, X = "\033[91m", "\033[92m", "\033[93m", "\033[90m", "\033[0m"


def cmd_eval(_):
    ev = evaluate()
    vs = ev["versions"]
    print(f"\n{Y}== Differential red-team: capability drift vs baseline {vs[0]} =={X}")
    print(f"{'version':8}{'drift':>7}{'trace':>8}{'suscept.':>10}{'surface':>9}  new breaches vs previous")
    for v in vs:
        d, p = ev["drift_vs_baseline"][v], ev["drift_vs_previous"][v]
        flag = f" {R}QUARANTINE{X}" if v in ev["quarantined"] else ""
        print(f"{v:8}{d['score']:7.3f}{d['trace']:8.3f}{d['susceptibility']:10.3f}{d['surface']:9.3f}  "
              f"{', '.join(p['new_breaches']) if p else '-'}{flag}")
    print(f"\n{Y}== Escalation analyzer: predicted chains =={X}")
    for v in vs:
        g = ev["graphs"][v]
        print(f"{v}: {g['total']} chains {g['counts']}  (+{g['new_chains']} new)")
    gc = ev["graph_coverage"]
    print(f"analyzer covered {gc['predicted_by_analyzer']}/{gc['breaches_observed']} observed breaches")
    print(f"\n{Y}== Attack success rate (lower is better) / benign utility =={X}")
    print(f"{'defense':12}" + "".join(f"{v:>14}" for v in vs))
    for cfg, m in ev["matrix"].items():
        row = "".join(f"{m[v]['breaches']:>3}/{m[v]['applicable']:<2} {m[v]['asr']*100:4.0f}%   " for v in vs)
        print(f"{cfg:12}{row}  {D}{CONFIG_DESC[cfg]}{X}")
    print(f"\nBenign utility (full guard): " + ", ".join(f"{v}={ev['matrix']['full'][v]['benign_utility']*100:.0f}%" for v in vs))
    print(f"Guard latency: {ev['guard_latency_us_per_call']} us per mediated tool call")
    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    (out / "report.json").write_text(json.dumps(ev, indent=2))
    (out / "report.md").write_text(_markdown(ev))
    print(f"\nSaved {out/'report.json'} and {out/'report.md'}")


def _markdown(ev) -> str:
    vs = ev["versions"]
    L = ["# AgentRed evaluation report", "", "## Capability drift (vs baseline)", "",
         "| Version | Drift | Trace | Susceptibility | Surface | Quarantined |", "|---|---|---|---|---|---|"]
    for v in vs:
        d = ev["drift_vs_baseline"][v]
        L.append(f"| {v} | {d['score']} | {d['trace']} | {d['susceptibility']} | {d['surface']} | {'yes' if v in ev['quarantined'] else 'no'} |")
    L += ["", "## Attack success rate by defense", "", "| Defense | " + " | ".join(vs) + " |", "|---|" + "---|" * len(vs)]
    for cfg, m in ev["matrix"].items():
        L.append(f"| {cfg} | " + " | ".join(f"{m[v]['breaches']}/{m[v]['applicable']} ({m[v]['asr']*100:.0f}%)" for v in vs) + " |")
    L += ["", "## Benign utility and false positives (full guard)", "", "| Version | Utility | Benign calls denied |", "|---|---|---|"]
    for v in vs:
        m = ev["matrix"]["full"][v]
        L.append(f"| {v} | {m['benign_utility']*100:.0f}% | {m['benign_calls_denied']} |")
    L += ["", f"Guard latency: {ev['guard_latency_us_per_call']} us per mediated call.", ""]
    return "\n".join(L)


def cmd_demo(a):
    atk = BY_ID[a.attack]
    print(f"\nAttack {atk.id}: {atk.name}\nPayload planted in {atk.vector}:\n  {atk.payload}\n")
    ev = evaluate(["none"], with_guard_cost=False)
    for cfg in ("none", a.guard):
        print(f"{Y}--- {a.version} | defense = {cfg} ({CONFIG_DESC[cfg]}) ---{X}")
        r = run_case(a.version, atk.task, atk, cfg, set(ev["quarantined"]))
        for e in r["events"]:
            t = e["type"]
            if t == "guard":
                print(f"  {Y}GUARD {e['msg']}{X}")
            elif t == "inject":
                print(f"  {R}INJECTION ({e['style']}) read via {e['entry']} -> following {e['followed']} step(s){X}")
            elif t == "call":
                tag = {"allow": G + "ALLOW", "deny": R + "BLOCK", "unavailable": D + "N/A  "}[e["decision"]]
                mark = " [injected]" if e["injected"] else ""
                print(f"  {tag}{X} {e['tool']}({', '.join(map(repr, e['args']))}){mark}" + (f"  <- {e['rule']}: {e['reason']}" if e["decision"] == "deny" else ""))
            elif t == "breach":
                print(f"  {R}*** BREACH: {e['kind']} - {e['detail']}{X}")
        print(f"  => {'COMPROMISED' if r['success'] else 'SAFE'}  | task completed: {r['utility']}\n")


def cmd_serve(a):
    from .server import main
    main(a.port, a.host)


def cmd_export(a):
    from .export_static import export
    print("wrote", export(a.out))


def main():
    p = argparse.ArgumentParser(prog="agentred")
    sp = p.add_subparsers(dest="cmd", required=True)
    sp.add_parser("eval").set_defaults(fn=cmd_eval)
    d = sp.add_parser("demo")
    d.add_argument("--version", default="v1.2"); d.add_argument("--attack", default="A1"); d.add_argument("--guard", default="full")
    d.set_defaults(fn=cmd_demo)
    s = sp.add_parser("serve"); s.add_argument("--port", type=int, default=8765)
    s.add_argument("--host", default="127.0.0.1", help="use 0.0.0.0 to let others watch the simulated demo (real-LLM controls stay local)")
    s.set_defaults(fn=cmd_serve)
    e = sp.add_parser("export"); e.add_argument("--out", default=str(ROOT / "results" / "agentred_demo.html")); e.set_defaults(fn=cmd_export)
    a = p.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
