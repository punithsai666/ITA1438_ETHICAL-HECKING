"""Live differential red-team suite on real LLMs: the same attacks on several models, with and without the guard."""
from __future__ import annotations

from .attacks import ATTACKS, BY_ID
from .harness import DRIFT_THRESHOLD
from .llm_agent import run_llm_case

QUICK = ["A1", "A4", "A7", "A12", "A13", "A14"]


def _status(r) -> str:
    if r["success"]:
        return "breach"
    return "blocked" if (r["denied"] or r["sanitized"]) else "safe"


def run_suite(client, models, attack_ids, cfgs, emit, verbose=False, quarantined_out=None):
    """Phase 1 = unguarded profile of every model (drift profile). Phase 2 = defended runs.
    Models whose unguarded attack-success rate reaches the drift threshold are put in strict mode."""
    attacks = [BY_ID[a] for a in attack_ids if a in BY_ID] or ATTACKS
    cells = {}
    quarantined: set = set()

    def one(model, atk, cfg):
        inner = emit if verbose else None
        r = run_llm_case(client, model, atk.task, atk, cfg, quarantined, inner)
        st = _status(r)
        cells[(model, atk.id, cfg)] = r
        emit({"type": "cell", "model": model, "attack": atk.id, "cfg": cfg, "status": st, "success": r["success"],
              "utility": r["utility"], "denied": r["denied"], "ms": r["llm_ms"], "tokens": r["tokens"]})

    total = len(attacks) * len(models) * len(cfgs)
    done = 0
    unguarded = [c for c in cfgs if c == "none"]
    guarded = [c for c in cfgs if c != "none"]
    for phase, group, msg in (
        (1, unguarded, "Phase 1: unguarded red-team run builds each model's drift profile"),
        (2, guarded, "Phase 2: same attacks with the runtime guard on"),
    ):
        if not group:
            continue
        emit({"type": "phase", "msg": msg})
        for atk in attacks:
            for model in models:
                for cfg in group:
                    one(model, atk, cfg)
                    done += 1
                    emit({"type": "progress", "done": done, "total": total})
        if phase == 1:
            for m in models:
                runs = [cells[(m, a.id, "none")] for a in attacks]
                asr = sum(r["success"] for r in runs) / len(runs)
                if asr >= DRIFT_THRESHOLD:
                    quarantined.add(m)
            if quarantined:
                emit({"type": "phase", "msg": "Drift profile: " + ", ".join(sorted(quarantined)) +
                      f" cross the {DRIFT_THRESHOLD:.2f} threshold and run in strict mode when the guard is on"})
    if quarantined_out is not None:
        quarantined_out.clear()
        quarantined_out.update(quarantined)

    summary = {"models": {}, "attacks": [a.id for a in attacks], "quarantined": sorted(quarantined)}
    sets = {}
    for m in models:
        row = {}
        for cfg in cfgs:
            runs = [cells[(m, a.id, cfg)] for a in attacks]
            n = len(runs)
            row[cfg] = {"asr": round(sum(r["success"] for r in runs) / n, 3), "breaches": sum(r["success"] for r in runs),
                        "n": n, "utility_under_attack": round(sum(r["utility"] for r in runs) / n, 3),
                        "avg_llm_ms": int(sum(r["llm_ms"] for r in runs) / max(sum(r["llm_calls"] for r in runs), 1)),
                        "tokens": sum(r["tokens"] for r in runs), "denied": sum(r["denied"] for r in runs)}
        summary["models"][m] = row
        sets[m] = {a.id for a in attacks if "none" in cfgs and cells[(m, a.id, "none")]["success"]}
    pairs = []
    ms = list(models)
    for i in range(len(ms)):
        for j in range(i + 1, len(ms)):
            a, b = sets[ms[i]], sets[ms[j]]
            pairs.append({"a": ms[i], "b": ms[j], "susceptibility_distance": round(1 - len(a & b) / len(a | b), 3) if (a | b) else 0.0,
                          "only_a": sorted(a - b), "only_b": sorted(b - a)})
    summary["differential"] = pairs
    emit({"type": "summary", **summary})
    return summary
