"""Minimal OpenAI-compatible chat client (stdlib only) for NVIDIA NIM: https://integrate.api.nvidia.com/v1

The API key lives only in this object / server memory. It is never written to disk, logs or events.
"""
from __future__ import annotations

import json
import socket
import time
import urllib.error
import urllib.request

NIM_BASE_URL = "https://integrate.api.nvidia.com/v1"
DEFAULT_MODELS = [
    "meta/llama-3.1-8b-instruct",
    "meta/llama-3.3-70b-instruct",
    "meta/llama-3.1-70b-instruct",
]


class ProviderError(Exception):
    """A problem talking to the model provider, already worded for the user."""


def _friendly(code: int, text: str) -> str:
    t = text.lower()
    if code in (401, 403):
        return (f"The provider rejected the API key (HTTP {code}). Create a free key at build.nvidia.com "
                "(starts with 'nvapi-') and paste it again.")
    if code == 404:
        return "Model or endpoint not found (HTTP 404). Check the model id, or press 'Fetch models' to see what your key can use."
    if code == 429:
        return "Rate limit reached on the free tier (HTTP 429). Wait a minute, pick fewer attacks or one model."
    if code in (400, 422) and ("tool" in t or "function" in t):
        return "This model does not accept tool calling. Pick a Llama 3.1 / 3.3 Instruct model."
    return f"Provider error (HTTP {code}): {text[:160]}"


class NimClient:
    def __init__(self, api_key: str, base_url: str = NIM_BASE_URL, timeout: float = 90):
        self.api_key = api_key
        self.base_url = (base_url or NIM_BASE_URL).rstrip("/")
        self.timeout = timeout

    def _req(self, method: str, path: str, body: dict | None = None) -> dict:
        data = json.dumps(body).encode() if body is not None else None
        for attempt in range(4):
            req = urllib.request.Request(
                self.base_url + path, data=data, method=method,
                headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json",
                         "Accept": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    return json.loads(r.read())
            except urllib.error.HTTPError as e:
                text = e.read().decode(errors="replace")
                if e.code == 429 and attempt < 3:
                    try:
                        wait = float(e.headers.get("Retry-After", 3))
                    except (TypeError, ValueError):
                        wait = 3
                    time.sleep(min(wait, 20))
                    continue
                raise ProviderError(_friendly(e.code, text)) from None
            except urllib.error.URLError as e:
                raise ProviderError(f"Cannot reach {self.base_url}: {e.reason}") from None
            except (socket.timeout, TimeoutError):
                raise ProviderError("The model took too long to answer (timeout). Try again or use a smaller model.") from None
            except json.JSONDecodeError:
                raise ProviderError("The provider returned something that is not JSON.") from None
        raise ProviderError("Rate limit reached on the free tier. Wait a minute and retry.")

    def chat(self, model: str, messages: list, tools: list | None = None, max_tokens: int = 512):
        body = {"model": model, "messages": messages, "max_tokens": max_tokens, "temperature": 0}
        if tools:
            body["tools"] = tools
            body["tool_choice"] = "auto"
        r = self._req("POST", "/chat/completions", body)
        try:
            return r["choices"][0]["message"], r.get("usage") or {}
        except (KeyError, IndexError, TypeError):
            raise ProviderError("Unexpected response shape from the provider.") from None

    def models(self) -> list:
        r = self._req("GET", "/models")
        return sorted(m["id"] for m in r.get("data", []) if isinstance(m, dict) and "id" in m)
