#!/usr/bin/env bash
# AgentRed Lab launcher (macOS / Linux). Needs Python 3.10+, nothing to install.
cd "$(dirname "$0")"
if [ -z "$NVIDIA_API_KEY" ]; then
  read -r -p "Paste your NVIDIA NIM key, or press Enter for simulated agents only: " NVIDIA_API_KEY
  export NVIDIA_API_KEY
fi
python3 -m unittest discover -s tests >/dev/null 2>&1 && echo "Self-tests passed." || echo "Self-tests reported a problem (see: python3 -m unittest discover -s tests)."
echo "Open http://localhost:${PORT:-8765}"
python3 -m agentred.cli serve --port "${PORT:-8765}"
