# AgentRed Lab

**Differential Red-Team Testing and Runtime Defense against Capability Drift and Cross-Tool Privilege Escalation in AI Agent Ecosystems**

A live demo application with two engines. Python 3.10+, standard library only (nothing to install).

| Engine | Needs | What it shows |
|---|---|---|
| **Simulated agents** | nothing | Four agent versions (v1.0 to v1.3) with designed drift, full evaluation, drift chart, escalation graph |
| **Real LLM (NVIDIA NIM)** | free NVIDIA key | A real model decides every tool call; same attacks, same guard, live in the browser |

## 1. Start it

* Windows: double-click `run.bat`
* macOS / Linux: `./run_demo.sh`
* Or directly: `python -m agentred.cli serve` then open http://localhost:8765

## 2. Get the free NVIDIA key (for the real-LLM engine)

1. Go to https://build.nvidia.com and sign in (free).
2. Open any model page (for example `llama-3.3-70b-instruct`) and press **Get API Key**. The key starts with `nvapi-`.
3. In the app switch to **Real LLM (NVIDIA NIM)**, paste the key, press **Save and test**.

The key is kept in the server's memory only. It is never saved to disk, never logged and never sent to the browser again. The real-LLM controls answer only to the computer running the server, so other people on your network cannot spend your quota. The free tier is rate limited: use the Quick suite (6 attacks) and one or two models.

No key yet? Press **Use offline mock**. It is a built-in provider that speaks the same API, so you can rehearse the whole real-LLM flow with no key and no internet.

## 3. Presentation script (about 5 minutes)

1. **Simulated agents, Auto demo.** Four steps: the baseline resists, v1.2 leaks a canary secret, a pattern filter is bypassed by a paraphrase, the full guard blocks it.
2. Scroll: attack matrix, drift chart (v1.2 is 0.53 from baseline), escalation graph (new chains per release).
3. **Real LLM mode.** Pick a model, defense = *No defense*, attack = A1, press **Launch attack**: watch the real model's own words and tool calls stream in.
4. Run again with defense = *Full runtime guard*: the same model is stopped, and the task still completes.
5. Tick two models, press **Run live red-team suite**: the table fills cell by cell; the summary compares the models (differential testing on real models).
6. **Write your own injection** and let the audience try to beat the guard.

## 4. The three modules

| Module | File | Role |
|---|---|---|
| 1. Differential Red-Team Harness | `harness.py`, `llm_suite.py` | Same attack suite on every version or model; drift score; models above the 0.30 threshold run in strict mode |
| 2. Cross-Tool Escalation Analyzer | `graph.py` | Tool-permission graph, ranked source-to-sink chains, new chains per release |
| 3. Runtime Defense Guard | `guard.py` | Content scan, capability manifest, provenance, sensitive-data flow, egress rules, drift quarantine |

Supporting: `tools.py` (sandbox, canary secrets), `attacks.py` (14 attacks), `detect.py` (independent breach oracle), `llm.py` / `llm_agent.py` (real-LLM client and agent loop), `mock_nim.py` (offline provider), `server.py` (live streaming server), `static/index.html` (dashboard).

## 5. Command line

```bash
python -m agentred.cli eval                       # full evaluation table, results/report.{json,md}
python -m agentred.cli demo --version v1.2 --attack A1 --guard full
python -m agentred.cli export                     # self-contained replay page (no server needed)
python -m agentred.llm_agent --model meta/llama-3.3-70b-instruct --attack A1 --guard full   # needs NVIDIA_API_KEY
python -m unittest discover -s tests              # 22 tests
```

## 6. Troubleshooting

| Message | Fix |
|---|---|
| Provider rejected the API key (401/403) | Create a new key at build.nvidia.com and paste it again |
| Model or endpoint not found (404) | Press **Fetch models for my key** and choose an id from the list |
| Rate limit reached (429) | Wait a minute, use the Quick suite, compare one model |
| Model does not accept tool calling | Use a Llama 3.1 / 3.3 Instruct model |
| Cannot reach ... | Check your internet connection or the Base URL (default `https://integrate.api.nvidia.com/v1`) |

## 7. Safety and honesty notes

* Everything is sandboxed. Tools are simulated, secrets are canary strings, `evil.test` is never contacted. Do not aim these payloads at systems you do not own.
* In real-LLM mode the model sees only simulated tools. "Injected" in a trace means *off-task*: outside the task's least-privilege manifest.
* The simulated agents are deterministic stand-ins; their percentages reflect designed profiles. Real-model numbers come from the Real LLM mode and will vary by model and run.
* The real NVIDIA call path was tested against the offline mock provider (same OpenAI-compatible protocol) but not against NVIDIA's servers in this build. If the first call fails, the app shows the reason; use **Fetch models** to confirm model ids.
* Capability manifests are written per task here; a production system would derive them from the user's request.
