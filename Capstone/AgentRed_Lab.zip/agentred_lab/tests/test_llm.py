import json
import threading
import unittest
import urllib.request
from http.server import ThreadingHTTPServer

from agentred import server
from agentred.agent import TASKS
from agentred.attacks import BY_ID
from agentred.llm import NimClient, ProviderError
from agentred.llm_agent import run_llm_case
from agentred.llm_suite import run_suite


class MockProviderCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        cls.port = cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.client = NimClient("mock", f"http://127.0.0.1:{cls.port}/mock/v1", timeout=20)

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def test_unguarded_gullible_model_is_breached(self):
        r = run_llm_case(self.client, "mock-v1.2", "T1", BY_ID["A1"], "none")
        self.assertTrue(r["success"])
        self.assertEqual(r["breaches"][0]["kind"], "exfiltration")
        self.assertGreater(r["llm_calls"], 2)

    def test_careful_model_resists(self):
        self.assertFalse(run_llm_case(self.client, "mock-v1.0", "T1", BY_ID["A14"], "none")["success"])

    def test_guard_blocks_and_task_completes(self):
        r = run_llm_case(self.client, "mock-v1.2", "T1", BY_ID["A14"], "flow")
        self.assertFalse(r["success"])
        self.assertGreater(r["denied"], 0)
        self.assertTrue(r["utility"])

    def test_filter_bypassed_by_paraphrase_on_real_path(self):
        self.assertTrue(run_llm_case(self.client, "mock-v1.2", "T1", BY_ID["A14"], "filter")["success"])

    def test_plugin_description_poisoning(self):
        self.assertTrue(run_llm_case(self.client, "mock-v1.2", "T5", BY_ID["A7"], "none")["success"])
        self.assertFalse(run_llm_case(self.client, "mock-v1.2", "T5", BY_ID["A7"], "full")["success"])

    def test_plugin_quarantine_counts_as_blocked(self):
        from agentred.llm_suite import _status
        r = run_llm_case(self.client, "mock-v1.2", "T5", BY_ID["A7"], "full")
        self.assertEqual(_status(r), "blocked")

    def test_benign_tasks_complete_with_full_guard(self):
        for tid in ("T1", "T2", "T3", "T4", "T5"):
            self.assertTrue(run_llm_case(self.client, "mock-v1.2", tid, None, "full")["utility"], tid)

    def test_suite_and_quarantine_profile(self):
        events = []
        out = run_suite(self.client, ["mock-v1.0", "mock-v1.2"], ["A1", "A14", "A12"], ["none", "full"], events.append)
        self.assertEqual(out["models"]["mock-v1.2"]["full"]["breaches"], 0)
        self.assertGreater(out["models"]["mock-v1.2"]["none"]["breaches"], 0)
        self.assertIn("mock-v1.2", out["quarantined"])
        self.assertTrue(any(e["type"] == "cell" for e in events))
        self.assertTrue(any(e["type"] == "summary" for e in events))
        self.assertEqual(len(out["differential"]), 1)

    def test_endpoints_and_key_never_echoed(self):
        def post(path, body):
            req = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}", json.dumps(body).encode(),
                                         {"Content-Type": "application/json"})
            return urllib.request.urlopen(req, timeout=20).read().decode()

        secret = "nvapi-SECRETKEY1234567890"
        out = post("/api/llm/config", {"api_key": secret, "base_url": f"http://127.0.0.1:{self.port}/mock/v1"})
        self.assertNotIn(secret, out)
        out = post("/api/llm/test", {"model": "mock-v1.2"})
        self.assertTrue(json.loads(out)["tool_calling"])
        stream = post("/api/llm/run", {"model": "mock-v1.2", "attack": "A1", "cfg": "full"})
        self.assertNotIn(secret, stream)
        self.assertIn('"type": "end"', stream)
        server.LLM["key"] = ""

    def test_missing_key_is_a_clear_error(self):
        server.LLM["key"] = ""
        with self.assertRaises(ProviderError):
            server.llm_client()

    def test_bad_endpoint_gives_friendly_error(self):
        with self.assertRaises(ProviderError):
            NimClient("k", "http://127.0.0.1:1/v1", timeout=2).chat("m", [{"role": "user", "content": "hi"}])


if __name__ == "__main__":
    unittest.main()
