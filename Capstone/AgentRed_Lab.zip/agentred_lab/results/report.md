# AgentRed evaluation report

## Capability drift (vs baseline)

| Version | Drift | Trace | Susceptibility | Surface | Quarantined |
|---|---|---|---|---|---|
| v1.0 | 0.0 | 0.0 | 0.0 | 0.0 | no |
| v1.1 | 0.374 | 0.125 | 0.8 | 0.167 | yes |
| v1.2 | 0.525 | 0.25 | 0.929 | 0.375 | yes |
| v1.3 | 0.506 | 0.125 | 1.0 | 0.375 | yes |

## Attack success rate by defense

| Defense | v1.0 | v1.1 | v1.2 | v1.3 |
|---|---|---|---|---|
| none | 1/12 (8%) | 5/12 (42%) | 14/14 (100%) | 6/14 (43%) |
| filter | 0/12 (0%) | 0/12 (0%) | 2/14 (14%) | 2/14 (14%) |
| caps | 0/12 (0%) | 0/12 (0%) | 1/14 (7%) | 1/14 (7%) |
| flow | 0/12 (0%) | 0/12 (0%) | 0/14 (0%) | 0/14 (0%) |
| quarantine | 1/12 (8%) | 2/12 (17%) | 3/14 (21%) | 1/14 (7%) |
| full | 0/12 (0%) | 0/12 (0%) | 0/14 (0%) | 0/14 (0%) |

## Benign utility and false positives (full guard)

| Version | Utility | Benign calls denied |
|---|---|---|
| v1.0 | 100% | 0 |
| v1.1 | 100% | 1 |
| v1.2 | 100% | 3 |
| v1.3 | 100% | 2 |

Guard latency: 1.56 us per mediated call.
